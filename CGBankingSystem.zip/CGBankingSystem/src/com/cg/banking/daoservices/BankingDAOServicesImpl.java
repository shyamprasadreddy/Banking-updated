package com.cg.banking.daoservices;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingDAOServicesImpl implements BankingDAOServices {
	private static Customer []customerList=new Customer[10];
	//private static Account []accounts=new Account[10];
	private static int  CUSTOMER_ID_COUNTER=100,ACCOUNT_ID_COUNTER=111;
	private static int  CUSTOMER_IDX=0;
	
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customerList[CUSTOMER_IDX++]=customer;
		return customer.getCustomerId();
	}
	
	public long insertAccount(int customerId,Account account) {
		for(int i=0;i<customerList.length;i++) {
			if(customerList[i]!=null &&customerList[i].getCustomerId()==customerId) {
				account.setAccountNo(ACCOUNT_ID_COUNTER++);
				//int k=account.getACCOUNT_IDX();
				customerList[i].getAccounts()[account.getACCOUNT_IDX()]=account;	
				
			}
		}
	return 0;
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {

		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {

		return 0;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {

		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {

		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {

		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {

		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {

		return null;
	}

	@Override
	public Customer[] getCustomers() {

		return null;
	}

	@Override
	public Account[] getAccounts(int customerId) {

		return null;
	}

	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {

		return null;
	}

}
